//
//  ViewController.swift
//  SheridanParking
//
//  Created by Xcode User on 2019-12-09.
//  Copyright © 2019 Inderpreet Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tfFirstName : UITextField!
    
    @IBOutlet var insertButton : UIButton!
    
    @IBAction func addData(){
        
        let getData = ParkingDAO()
        
        getData.jsonParser(name: tfFirstName.text!)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

